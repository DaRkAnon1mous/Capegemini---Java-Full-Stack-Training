package com.ecp.controller;


import com.ecp.model.Order;
import com.ecp.service.OrderService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ECP")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping(value = "/add")
    public boolean add(@RequestBody Order order) {
        return orderService.add(order);
    }
}

