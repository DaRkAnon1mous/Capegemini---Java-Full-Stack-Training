package com.ecp.controller;

import com.ecp.model.User;
import com.ecp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ECP")
public class UserController {

    @Autowired
    private UserService service;

    @PostMapping(value = "/add")
    public boolean add(@RequestBody User user) {
        return service.add(user);
    }
}
