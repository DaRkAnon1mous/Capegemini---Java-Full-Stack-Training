package com.validate;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.model.Candidate;

@Component
public class CustomValidator implements Validator {
    
    @Override
    public boolean supports(Class<?> clazz) {
        return clazz == Candidate.class;
    }
    
    @Override
    public void validate(Object arg0, Errors arg1) {
        Candidate candidate = (Candidate) arg0;
        
        // Validate candidate name
        if (candidate.getCandidateName() != null && !candidate.getCandidateName().isEmpty()) {
            if (!candidate.getCandidateName().matches("[a-zA-Z ]{5,10}")) {
                arg1.rejectValue("candidateName", "error.candidate", 
                    "Name should contain only alphabets and space min 3 chars and max 10 chars");
            }
        }
        
        // Validate contact number
        if (candidate.getContactNumber() != null && !candidate.getContactNumber().isEmpty()) {
            if (!candidate.getContactNumber().matches("[6-9]\\d{9}")) {
                arg1.rejectValue("contactNumber", "error.candidate", 
                    "Contact Number should be of 10 digits/Contact Number should start with range 6 to 9");
            }
        }
    }
}