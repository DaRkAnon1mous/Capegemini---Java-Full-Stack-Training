package com.test;
import com.exception.InvalidOnlineOrderException;
import com.model.OnlineOrder;
import com.test.Main;
import com.util.EStore;
import org.junit.jupiter.api.BeforeAll;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

class EStoreTest {
    private EStore eStore;
    private List<OnlineOrder> orderList;

    @BeforeEach
    void setUp() {
        eStore = new EStore();
        orderList = new ArrayList<>();

        orderList.add(new OnlineOrder(101, "Alice", "Laptop", "Electronics", 1, "Home Delivery", 50000));
        orderList.add(new OnlineOrder(102, "Bob", "Smartphone", "Mobiles", 2, "Pick Up", 30000));
        orderList.add(new OnlineOrder(103, "Charlie", "Mask", "Essentials", 5, "Home Delivery", 500));
        orderList.add(new OnlineOrder(104, "David", "Shirt", "Fashion", 3, "Pick Up", 1500));
        
        eStore.setOnlineOrderList(orderList);
    }

    @Test
    void test11ValidateItemTypeWhenElectronics() throws InvalidOnlineOrderException {
        assertTrue(eStore.validateItemType("Electronics"));
    }

    @Test
    void test12ValidateItemTypeWhenMobiles() throws InvalidOnlineOrderException {
        assertTrue(eStore.validateItemType("Mobiles"));
    }

    @Test
    void test13ValidateItemTypeWhenEssentials() throws InvalidOnlineOrderException {
        assertTrue(eStore.validateItemType("Essentials"));
    }

    @Test
    void test14ValidateItemTypeWhenFashion() throws InvalidOnlineOrderException {
        assertTrue(eStore.validateItemType("Fashion"));
    }

    @Test
    void test15ValidateItemTypeWhenInvalid() {
        assertThrows(InvalidOnlineOrderException.class, () -> eStore.validateItemType("Toys"));
    }

    @Test
    void test16ViewOnlineOrdersByOrderIdWhenValid() throws InvalidOnlineOrderException {
        OnlineOrder order = eStore.viewOnlineOrdersByOrderId(101);
        assertNotNull(order);
        assertEquals(101, order.getOrderId());
        assertEquals("Alice", order.getCustomerName());
    }

    @Test
    void test17ViewOnlineOrdersByOrderIdWhenInvalid() {
        assertThrows(InvalidOnlineOrderException.class, () -> eStore.viewOnlineOrdersByOrderId(999));
    }
}
