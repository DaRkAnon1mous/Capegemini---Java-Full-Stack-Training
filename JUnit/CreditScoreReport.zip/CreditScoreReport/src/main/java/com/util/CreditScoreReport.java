package com.util;

import com.exception.InvalidConsumerException;
import com.model.Consumer;
import java.util.*;

public class CreditScoreReport {
    private List<Consumer> consumerList;

    public void setConsumerList(List<Consumer> consumerList) {
        this.consumerList = consumerList;
    }

    public Map<Integer, Integer> totalConsumerCountForEachCreditScoreRange() throws InvalidConsumerException {
        if (consumerList == null || consumerList.isEmpty()) {
            throw new InvalidConsumerException("Consumer list is empty");
        }

        // Initialize map with keys to ensure they exist
        Map<Integer, Integer> scoreMap = new HashMap<>();
        scoreMap.put(800, 0); // Excellent
        scoreMap.put(600, 0); // Good
        scoreMap.put(500, 0); // Fair
        scoreMap.put(300, 0); // Poor

        // Count consumers in each range
        for (Consumer consumer : consumerList) {
            int score = consumer.getCreditScore();
            if (score >= 800) {
                scoreMap.put(800, scoreMap.get(800) + 1);
            } else if (score >= 600) {
                scoreMap.put(600, scoreMap.get(600) + 1);
            } else if (score >= 500) {
                scoreMap.put(500, scoreMap.get(500) + 1);
            } else {
                scoreMap.put(300, scoreMap.get(300) + 1);
            }
        }
        return scoreMap;
    }

    public String viewConsumerReportBasedOnCreditScore(int creditScore) throws InvalidConsumerException {
        if (consumerList == null || consumerList.isEmpty()) {
            throw new InvalidConsumerException("Consumer list is empty");
        }

        if (creditScore < 300 || creditScore > 900) {
            throw new InvalidConsumerException("Invalid credit score range");
        }

        if (creditScore >= 800) return "EXCELLENT";
        if (creditScore >= 600) return "GOOD";
        if (creditScore >= 500) return "FAIR";
        return "POOR";
    }
}