package com.exception;
public class InvalidConsumerException extends Exception{
	public InvalidConsumerException (String message)
	{
		super(message);
	}

}
