package com.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.Mockito.*;

import com.model.Employee;
import com.service.EmployeeService;
import com.repo.EmployeeRepo;

@ExtendWith(MockitoExtension.class)
public class EmployeeTest {
    
    @Mock
    private EmployeeRepo repo;
    
    @InjectMocks
    private EmployeeService service;
    
    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // Test the addEmployee method in EmployeeService class
    @Test
    public void test1AddEmployee() {
        Employee employee = new Employee(1, "John Doe", "john.doe@example.com", 50000);
        when(repo.addEmployeeToList(employee)).thenReturn(1);
        assertEquals(1, service.addEmployee(employee));
    }
    
    // Test the deleteEmployee method in EmployeeService class
    @Test
    public void test2DeleteEmployee() {
        Employee employee = new Employee(2, "Jane Doe", "jane.doe@example.com", 60000);
        doNothing().when(repo).deleteEmployeeFromList(employee);
        service.deleteEmployee(employee);
        verify(repo, times(1)).deleteEmployeeFromList(employee);
    }
    
    // Test the fetchEmployeeById method in EmployeeService class for a valid employeeId
    @Test
    public void test3FetchEmployeeByEmployeeId() {
        Employee employee = new Employee(3, "Alice Smith", "alice.smith@example.com", 70000);
        when(repo.getEmployeeByEmployeeId(3)).thenReturn(employee);
        assertEquals(employee, service.fetchEmployeeById(3));
    }
    
    // Test the fetchEmployeeById method in EmployeeService class for an invalid employeeId
    @Test
    public void test4FetchEmployeeByEmployeeIdWhenNull() {
        when(repo.getEmployeeByEmployeeId(99)).thenReturn(null);
        assertThrows(NullPointerException.class, () -> service.fetchEmployeeById(99));
    }
    
    // Test the fetchEmployee method in EmployeeService class
    @Test
    public void test5FetchEmployee() {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(4, "Bob Brown", "bob.brown@example.com", 80000));
        employees.add(new Employee(5, "Charlie Green", "charlie.green@example.com", 90000));
        
        when(repo.getEmployee()).thenReturn(employees);
        assertEquals(employees, service.fetchEmployee());
    }
}
